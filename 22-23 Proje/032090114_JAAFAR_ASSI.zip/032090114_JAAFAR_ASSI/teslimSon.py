#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


df1= pd.read_excel("dataset_twitter-scraper_2023-05-14_14-41-25-798.xlsx")


# In[3]:


dfHashtags = df1[['hashtags/0', 'hashtags/1' ,'hashtags/2', 'hashtags/3']]


# In[4]:


dfHashtags.isnull().sum()


# In[5]:


df=df1[['created_at', 'full_text', 'hashtags/0', 'is_retweet', 'url','user/created_at', 'user/name']]
df = df.rename(columns={'hashtags/0': 'hastags'})


# In[6]:


df.columns


# In[7]:


df=df[df['full_text'].isnull() == False]


# In[8]:


len(df)


# In[9]:


"""
sozluk = {"ç": "c",  "ğ": "g",  "ı": "i",  "ö": "o",  "ş": "s", "ü": "u"}

lll=#kelime listesi 
l2 = list(map(lambda kelime: ''.join([sozluk.get(i, i) for i in kelime]), lll))

print(l2)
"""


# In[10]:


class tvit:
    def __init__(self,tweet):
        from zemberek import (TurkishSpellChecker,TurkishSentenceNormalizer,TurkishSentenceExtractor,TurkishMorphology,TurkishTokenizer)
        

        self.tweet0 = tweet.full_text or ""
        self.tweet = tweet.full_text or ""
        self.username = tweet.url.split("/")[-3] or ""
        self.url = tweet.url or ""
        self.created_at = tweet.created_at or ""
        self.hashtags=tweet.hastags or ""
        self.deprem = False
        self.ihtiyac = False
        self.ihtiyacListesi=[]
        self.retweet=tweet.is_retweet
        self.word_counts ={}
        self.usernames=[]
        self.erzak_ihtiyaci = ['su', 'gidaya', 'giyim', 'bez', 'icecek', 'biskuvi',  'pirinc','yemek','yemis','bakliyat','gida', 'yiyecek', 'mamasi', 'icecek','mama', 'konserve', 'biskuvi','meyve', 'kraker', 'yemis', 'meyve', 'suyu', 'sut','giyecek', 'seker', 'tuz', 'yag', 'erzak']
        self.giyim_ihtiyaci = [ 'pijama', 'bere','pantolon', 'bot','ayakkabi','kiyafet','kazak', 'yatak','camasiri', 'esofman', 'corabi','bezi','mont', 'polar', 'sweatshirt', 'bere', 'atlet', 'corap', 'termal', 'iclik']
        self.isinma_ihtiyaci = [    'battaniye', 'tup', 'soba','yorgan', 'sicak', 'su', 'torba', 'kat', 'kalorifer', 'odun', 'komur', 'elektrikli', 'isitici']
        self.barinma_ihtiyaci = [ 'cadir', 'mat', 'uyku', 'tulumu', 'kamp', 'yatacak', 'sandalyesi', 'sandalye', 'masasi', 'fener']
        self.hijyen_listesi = [  'pecete', 'pedi','deterjan', 'sabun', 'dezenfektan', 'sabun', 'eldiven', 'maske', 'ped', 'tampon', 'hijyen', 'temizlik', 'malzemeleri', 'saglik', 'maske','bandaj','ilac','hijyenik', 'dezenfektan','pecete']
        self.farkli_ihtiyac = [  'yardim',  'ihtiyaclarini', 'yardimina','yardimi', 'yardimina','ihtiyaclari','ihtiyaci','ihtiyac' ,'lazim','urunleri','powerbank',   'malzemesi', 'konserve','kiyafeti', 'kalorifer', 'ihtiyacimiz', 'hasta',  'engelli','hastasi',   'ihtiyaclarini']
        self.tumihtiyacLar=list(self.erzak_ihtiyaci+self.giyim_ihtiyaci+self.isinma_ihtiyaci+self.barinma_ihtiyaci+self.hijyen_listesi+self.farkli_ihtiyac)

        self.harfSozluk= { "ç": "c","ğ": "g","ı": "i","ö": "o","ş": "s","ü": "u"}
        
        self.stopWords=['milyon', 'trilyon', 'onlar', 'seksen','var','yok' 'ama', 'buna', 'bizim', 'neyden', 'yirmi', 'alti', 'iki', 
                 'seni', 'doksan', 'dort', 'bunun', 'ki', 'nereye','hem', 'kez', 'otuz', 'ben','altmis','elli',
                 'bizi', 'da', 'sekiz', 've', 'cok', 'bu', 'veya', 'ya', 'kirk', 'onlarin', 'ona', 'bana', 'yetmis', 
                 'milyar', 'bunu', 'senden', 'birseyi', 'dokuz', 'yani', 'kimi', 'seyler', 'kim', 'neden', 'senin', 'yedi',
                 'niye', 'uc', 'sey', 'mu', 'tum', 'onlari', 'bunda', 'ise', 'þundan', 'hep', 'buna', 'bin', 'ben', 'ondan',
                 'kimden', 'bazi', 'belki', 'ne', 'bundan', 'gibi', 'de', 'onlardan', 'sizi', 'sizin', 'daha', 'nicin', 'bunda',
                 'bunu', 'beni', 'ile', 'bu', 'neyi', 'sizden', 'defa', 'biz', 'icin', 'dahi', 'siz', 'nerde', 'kime', 
                 'birsey','birkez', 'her', 'biri', 'on', 'mu', 'diye', 'acaba', 'sen', 'en', 'hepsi', 'bir', 'bizden','sanki',
                 'benim','nerede', 'onu', 'benden', 'yuz', 'birkac', 'cunku','nasil','hic','katrilyon','oldu','abi','nere', 'de',
                 '0','1','2','3','4','5','6','7','8','9']

        self.depremSozcuk=['buyukluk','afad', 'deprem', 'depremin', 'depremler', 'depremlerin', 'derinlik', 'enkaz', 'hasar', 'depremde', 'depremleri', 'depremlerinden', 'depremzede']
    def yaz(self):
        print("twit :",self.tweet)
        print("username :",self.username)
        print("url :",self.url)
        print("created_at :",self.created_at)
        print("hashtags :",self.hashtags)
        print("deprem :",self.deprem)
        print("ihtiyac :",self.ihtiyac)
        print("is_retweet : ", self.retweet)
        print("world_count",self.word_counts)
        print("etiketlenen",self.usernames)
        
    def stopWords(self):
        pass

    def getRoot(self,word):

        from zemberek import (TurkishSpellChecker,TurkishSentenceNormalizer,TurkishSentenceExtractor,TurkishMorphology,TurkishTokenizer)

        morphology = TurkishMorphology.create_with_defaults()

        # SINGLE WORD MORPHOLOGICAL ANALYSIS
        
        
        results = morphology.analyze(word)
        for result in results:
            analysis = str(result)
            root = analysis.split(":")[0].split("[")[1]
            return root
            
        return word
            
        
    def count_words(self):
        from zemberek import (TurkishSpellChecker,TurkishSentenceNormalizer,TurkishSentenceExtractor,TurkishMorphology,TurkishTokenizer)
        

        # Sözlük oluşturmak için boş bir sözlük tanımla
        word_counts = {}
        
        # Kelime sayma işlemi
        ####words=self.tweet.split()
        
        words=[str(i).split()[0].strip('[') for i in TurkishTokenizer.DEFAULT.tokenize(self.tweet)]
        
        
        for word in words:
            #word=getRoot(word)#
            #print(type(word),word)
            if len(word)>2 and word not in self.stopWords and word.isalpha():
                if  word in word_counts:
                    word_counts[word] += 1
                else:
                    word_counts[word] = 1

        self.word_counts =word_counts
        
    def tweet_normalize(self):
        from zemberek import TurkishSentenceNormalizer,TurkishMorphology

        morphology = TurkishMorphology.create_with_defaults()
        # SENTENCE NORMALIZATION
        normalizer = TurkishSentenceNormalizer(morphology)
        self.tweet= normalizer.normalize(self.tweet)


    def fullTextPr(self):
        import string
        import re
        
        #self.tweet_normalize()
        
        # kucuk harflere çevirir
        self.tweet = str(self.tweet).lower()
        
        self.tweet = self.tweet.replace('\n', ' ')

        #URL'leri metinden kaldır
        self.tweet = re.compile(r'http\S+').sub('', self.tweet)
        
        
        self.tweet = re.compile(r'@\w+').sub('', self.tweet)

        #turkçe karakterleri ingilizceye çevirir
        self.tweet = self.tweet.translate(str.maketrans(self.harfSozluk))
        
        #noktalama işaretleri siler
        self.tweet = self.tweet.translate(str.maketrans('', '', string.punctuation))
        
        # sayiları siler
        self.tweet = self.tweet.translate(str.maketrans('', '', string.digits))
      

        
        self.count_words()
        
    def depremMi(self):
        for term in self.depremSozcuk:
            if term in self.tweet:
                self.deprem=True
  
    def ihtiyac_kontrol(self):
        ihtiyacList=[]

        arama_sozluk = {"erzak":self.erzak_ihtiyaci,"giyim":self.giyim_ihtiyaci,"isinma":self.isinma_ihtiyaci,"barinma":self.barinma_ihtiyaci,"hijyen":self.hijyen_listesi,"farkli_ihtiyac":self.farkli_ihtiyac}

        for k, v in arama_sozluk.items():
            for ihtiyac in v:
                if ihtiyac in self.tweet:
                    ihtiyacList.append(k)
                    break
        if len(ihtiyacList)>0:
            self.ihtiyac=True
        self.ihtiyacListesi = ihtiyacList
     


# In[11]:


def df2list(df):
    nesneler_list = []
    for index, row in df.iterrows():
        veri = tvit(row)
        nesneler_list.append(veri)
    return nesneler_list


# In[12]:


import pandas as pd

def tweets_to_dataframe(tweets):
    data = {'tweet': [], 'deprem': [], 'ihtiyac': [], 'created_at': [], 'hashtags': [], 'word_counts': [], "url": []}
    for tweet in tweets:
        data['tweet'].append(tweet.tweet0)
        data['deprem'].append(tweet.deprem)
        data['ihtiyac'].append(tweet.ihtiyac)
        data['created_at'].append(tweet.created_at)
        data['hashtags'].append(tweet.hashtags)
        data['word_counts'].append(tweet.word_counts)
        data['url'].append(tweet.url)
    
    df = pd.DataFrame(data)
    return df


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[14]:


def tweet_processing(twitler):
    [i.fullTextPr() for i in twitler];
    [i.depremMi() for i in twitler];
    [i.ihtiyac_kontrol() for i in twitler];


# In[15]:


def bul1(objs,arananTip,arananDeger):
    if len(objs)==1:
        print(getattr(i,arananTip)==arananDeger)
    x=[i for i in objs if getattr(i,arananTip)==arananDeger]
    return x


# In[16]:


def ToplamSozluk(isetenenTwitler,minTekrar=1):
    toplam_sozluk = {}
    
    for tweet in isetenenTwitler:
        for key, value in tweet.word_counts.items():
            toplam_sozluk[key] = toplam_sozluk.get(key, 0) + value

    for i in list(toplam_sozluk.keys()):
        if toplam_sozluk[i]<minTekrar:
            del toplam_sozluk[i]

    print(len(toplam_sozluk))
    toplam_sozluk =sorted(toplam_sozluk.items(), key=lambda x: x[1], reverse=True)
    return toplam_sozluk


# In[17]:


def getAnahtarlar(toplam_sozluk):
    anahtarlar=[]

    for i in  toplam_sozluk:
        anahtarlar.append(i[0])
    return anahtarlar


# In[18]:


twitler=df2list(df)


# In[19]:


tweet_processing(twitler)


# In[20]:


twitler=[i for i in twitler if list(i.word_counts.keys())!=['nan'] or list(i.word_counts.keys())!=[] ]
len(twitler)


# In[49]:


# DataFrame'i tamamı görüntülemek için ayarlar
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)


# In[50]:


ihtiyacTwit=bul1(twitler,"ihtiyac",True)
ihtiyacDf=tweets_to_dataframe(ihtiyacTwit)
ihtiyacDf


# In[51]:


sondf = tweets_to_dataframe(twitler)
sondf[sondf["deprem"] == True]


# In[ ]:





# In[23]:


depremTwit=bul1(twitler,"deprem",True)


# In[24]:


depremTwit[1].yaz()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# # anahtar kelimeleri tespiti için bazı metotlar
# * kullanılan eşsiz kelimeleri yazdırarak gözde geçirip  ihtiyac listesi ve deprem ihbarında kullanılan kelimeleri tepi edilir 

# In[25]:


is_retweet=bul1(twitler,"retweet",True)


# In[26]:


len(bul1(bul1(twitler,"ihtiyac",False),"deprem",False))


# In[27]:


isetenenTwitler=bul1(twitler,"deprem",True)
toplam_sozluk = ToplamSozluk(isetenenTwitler,2)
kesisim_deprem = set(getAnahtarlar(toplam_sozluk)) & set(twitler[0].depremSozcuk)
fark_deprem =  set(getAnahtarlar(toplam_sozluk)) - set(twitler[0].depremSozcuk) 
len(fark_deprem)
fark_deprem


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[28]:


import zemberek
import time
import logging

from zemberek import (TurkishSpellChecker,TurkishSentenceNormalizer,TurkishSentenceExtractor,TurkishMorphology,TurkishTokenizer)


# In[29]:


twitler[43].tweet


# In[30]:


def SENTENCE_NORMALIZATION(examples):
    morphology = TurkishMorphology.create_with_defaults()
    # SENTENCE NORMALIZATION
    start = time.time()
    normalizer = TurkishSentenceNormalizer(morphology)

    start = time.time()
    for example in examples:
        print(example)
        print(normalizer.normalize(example), "\n")



# In[31]:


examples = ["Yrn okua gidicem",
            "Tmm, yarin havuza giricem ve aksama kadar yaticam :)",
            "ah aynen ya annemde fark ettı siz evinizden cıkmayın diyo",
            "gercek mı bu? Yuh! Artık unutulması bile beklenmiyo",
            "Hayır hayat telaşm olmasa alacam buraları gökdelen dikicem.",
            "yok hocam kesınlıkle oyle birşey yok",
            "herseyi soyle hayatında olmaması gerek bence boyle ınsanların falan baskı yapıyosa",
            "email adresim zemberek_python@loodos.com",
            "Kredi başvrusu yapmk istiyrum.",
            "Bankanizin hesp blgilerini ogrenmek istyorum."]
SENTENCE_NORMALIZATION(['Perşembe Akşamı 21.00de @BabalaTv de. https://t.co/g8yk8MzM1G','@NumanServet33 Haklısın ya inan haklısın.\nDüzelteceğim '])


# In[32]:


def  SPELLING_SUGGESTION(li):
    morphology = TurkishMorphology.create_with_defaults()
    sc = TurkishSpellChecker(morphology)
    # SPELLING SUGGESTION
    for word in li:
        print(word + " = " + ' '.join(sc.suggest_for_word(word)))


# In[33]:



def extraktor(text):

    extractor = TurkishSentenceExtractor()
    sentences = extractor.from_paragraph(text)

    for sentence in sentences:
        print(sentence)
    print("\n")


# In[34]:


text = "İnsanoğlu aslında ne para ne sevgi ne kariyer ne şöhret ne de çevre ile sonsuza dek mutlu olabilecek bir "    "yapıya sahiptir. Dış kaynaklardan gelebilecek bu mutluluklar sadece belirli bir zaman için insanı mutlu "    "kılıyor. Kişi bu kaynakları elde ettiği zaman belirli bir dönem için kendini iyi hissediyor, ancak alışma "    "dönemine girdiği andan itibaren bu iyilik hali hızla tükeniyor. Mutlu olma sanatının özü bu değildir. Gerçek "    "mutluluk, kişinin her türlü olaya ve duruma karşı kendini pozitif tutarak mutlu hissedebilmesi halidir. Bu "    "davranış şeklini edinen insan, zor günlerde güçlü, mutlu günlerde zevk alan biri olur ve mutluluğu kalıcı "    "kılar. "

extraktor(text)


# In[35]:


def getRoot(word):
    
    # Kelimenin kökünü bul.
    from zemberek import TurkishMorphology
    morphology = TurkishMorphology.create_with_defaults()
    results = morphology.analyze(word)
    for result in results:
        analysis = str(result)
        root = analysis.split(":")[0].split("[")[1]
        return root
        


# In[36]:


s=getRoot(" depremlerin ")


# In[37]:


s


# In[38]:


# SENTENCE ANALYSIS AND DISAMBIGUATION
def analyze2(sentence="Yarın kar yağacak."):
    from zemberek import TurkishMorphology
    
    morphology = TurkishMorphology.create_with_defaults()
    analysis = morphology.analyze_sentence(sentence)
    after = morphology.disambiguate(sentence, analysis)

    print("\nBefore disambiguation")
    for e in analysis:
        print(f"Word = {e.inp}")
        for s in e:
            print(s.format_string())

    print("\nAfter disambiguation")
    for s in after.best_analysis():
        print(s.format_string())


# In[39]:


analyze2(twitler[2].tweet0)


# In[40]:


def TOKENIZATon(t="Saat 12:00."):
    # TOKENIZATION
    tokenizer = TurkishTokenizer.DEFAULT

    tokens = tokenizer.tokenize(t)
    return tokens


# In[41]:


sonuc = TOKENIZATon("depremzedelerin ihtiyacları ")
sonuc
#[str (i).split()[0].rsplit('[')[1] for i in sonuc]


# In[42]:


def count_words1(text):
    # Tokenization
    tokenizer = TurkishTokenizer.DEFAULT
    tokens = tokenizer.tokenize(text)

    # Morphological analysis
    morphology = TurkishMorphology.create_with_defaults()
    analysis = [morphology.analyze(token.content) for token in tokens]

    # Disambiguation
    disambiguated = [morphology.disambiguate(token.content, analysis[i]).best_analysis() for i, token in enumerate(tokens)]

    # Stopword removal and word count
    stopWords = set(stopwords.words('turkish'))
    word_counts = {}
    for i, word in enumerate(disambiguated):
        root = word[0].format_long()
        if len(root) > 2 and root not in stopWords and root.isalpha():
            if root in word_counts:
                word_counts[root] += 1
            else:
                word_counts[root] = 1

    return word_counts


# In[43]:


words=twitler[1].tweet.split()


# In[44]:


words2=[str(i).split()[0].strip('[') for i in TOKENIZATon(twitler[1].tweet)]


# In[45]:


words2


# In[46]:


from zemberek import TurkishSpellChecker

def fullTextPr(self):
    import string
    import re
    from zemberek import (
        TurkishSpellChecker,
        TurkishSentenceNormalizer,
        TurkishSentenceExtractor,
        TurkishMorphology,
        TurkishTokenizer
    )
    # kucuk harflere çevirir
    self.tweet = str(self.tweet).lower()

    self.tweet = self.tweet.replace('\n', ' ')

    #URL'leri metinden kaldır
    self.tweet = re.compile(r'http\S+').sub('', self.tweet)


    self.tweet = re.compile(r'@\w+').sub('', self.tweet)

    #turkçe karakterleri ingilizceye çevirir
    self.tweet = self.tweet.translate(str.maketrans(self.harfSozluk))

    # yazım hatalarını düzeltir
    morphology = TurkishMorphology.create_with_defaults()
    spell_checker = TurkishSpellChecker(morphology)
    words = self.tweet.split()
    corrected_words = []
    for word in words:
        suggestions = spell_checker.suggest_for_word(word)
        if suggestions:
            corrected_words.append(suggestions[0])
        else:
            corrected_words.append(word)
    self.tweet = ' '.join(corrected_words)

    #noktalama işaretleri siler
    self.tweet = self.tweet.translate(str.maketrans('', '', string.punctuation))

    # sayiları siler
    self.tweet = self.tweet.translate(str.maketrans('', '', string.digits))

    self.count_words()


# In[ ]:





# In[47]:


from zemberek import TurkishTokenizer, TurkishMorphology

# Kelimelerin köklerini çıkarma fonksiyonu
def kelime_koklerini_bul(kelimeler):
    morphology = TurkishMorphology.create_with_defaults()
    for kelime in kelimeler:
        # Zemberek tokenizer'ı kullanarak kelimeyi tokenleştirmek
        tokenler = TurkishTokenizer.DEFAULT.tokenize(kelime)
        for token in tokenler:
            # Token'ı çözümleme
            analysis = morphology.analyze(token).bestAnalysis()
            # Kökü bulma ve yazdırma
            print(analysis.getStem())


# In[ ]:





# In[56]:


"""from zemberek import TurkishTokenizer, TurkishMorphology

# Kelimelerin köklerini çıkarma fonksiyonu
def kelime_koklerini_bul(kelimeler):
    morphology = TurkishMorphology.create_with_defaults()
    for kelime in kelimeler:
        # Zemberek tokenizer'ı kullanarak kelimeyi tokenleştirmek
        tokenler = TurkishTokenizer.DEFAULT.tokenize(kelime)
        for token in tokenler:
            # Token'ı çözümleme
            analysis = morphology.analyze(token)
            # Kökü bulma ve yazdırma
            print(analysis.getStem())


icerikler = ['Deprem sonrası hasar tespit çalışmaları devam ediyor', 
             'Depremzedeler için gıda yardımı yapılacak', 
             'Yaralıların sayısı 50 oldu']

kelime_koklerini_bul(icerikler[0])"""


# In[ ]:





# In[53]:


def replace_with_root(text):
    import string
    # Kelimeleri kökleri ile değiştir
    text = text.translate(str.maketrans('', '', string.punctuation))
    
    words = text.split()
    new_words = []
    for word in words:
        root = getRoot(word)
        new_words.append(root)

    return new_words


# In[54]:


text = "Bugün havalar çok güzel ve güneşli."
new_text = replace_with_root(text)
print(new_text)


# In[ ]:





# In[ ]:





# In[55]:


words = ['basta', 'ulu', 'onderimiz', 'mustafa', 'kemal', 'ataturk', 'olmak', 'uzere',
 'canakkale’yi', 'gecilmez', 'kilan', 'tum', 'sehitlerimizi', 've', 'gazilerimizi', 'saygiyla', 'minnetle', 've', 'rahmetle',
 'aniyoruz', 'mart', 'canakkale', 'zaferimizin', 'yili', 'kutlu', 'olsun']






